from .core import *

VERTEX_BUFFER_POS_OFFSET = core._py_vertex_buffer_vertex_pos_offset()
VERTEX_BUFFER_UV_OFFSET = core._py_vertex_buffer_vertex_uv_offset()
VERTEX_BUFFER_COL_OFFSET = core._py_vertex_buffer_vertex_col_offset()
VERTEX_SIZE = core._py_vertex_buffer_vertex_size()
INDEX_SIZE = core._py_index_buffer_index_size()
